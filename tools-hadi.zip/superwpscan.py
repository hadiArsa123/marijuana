import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
import os

# ====== CONFIG ======
wp_paths = [
    "/wp-login.php",
    "/wp/wp-login.php",
    "/blog/wp-login.php",
    "/cms/wp-login.php",
    "/admin/wp-login.php"
    "/wordpress/wp-login.php"
]

batch_size = 10000      # jumlah URL per batch
max_threads = 1000      # jumlah thread per batch
timeout_sec = 5         # timeout per request
found_file = "found_wp.txt"  # file hasil

# ====== FUNSI CEK ======
def check_wp(url):
    """Cek semua kemungkinan path WordPress login, return path pertama ditemukan"""
    for path in wp_paths:
        target = url.rstrip("/") + path
        try:
            response = requests.get(target, timeout=timeout_sec)
            if response.status_code == 200:
                return target
        except requests.RequestException:
            continue
    return None

def process_batch(batch, batch_number):
    found_urls = []
    total = len(batch)
    start_time = time.time()
    
    with ThreadPoolExecutor(max_workers=max_threads) as executor:
        futures = {executor.submit(check_wp, url): url for url in batch}
        completed = 0
        for future in as_completed(futures):
            result = future.result()
            completed += 1
            if result:
                found_urls.append(result)
                print(f"[FOUND] {result}")
            
            # Progress & estimasi waktu
            if completed % 100 == 0 or completed == total:
                elapsed = time.time() - start_time
                percent = completed / total * 100
                est_total = elapsed / (completed / total)
                est_remaining = est_total - elapsed
                print(f"Batch {batch_number} Progress: {completed}/{total} ({percent:.2f}%), "
                      f"Elapsed: {int(elapsed)}s, Est Remaining: {int(est_remaining)}s", end='\r')
    
    # Simpan hasil batch
    if found_urls:
        with open(found_file, "a") as f:
            for url in found_urls:
                f.write(url + "\n")
    print()  # newline setelah batch selesai

# ====== MAIN ======
if __name__ == "__main__":
    list_file = input("Masukkan nama file list (misal: list.txt): ").strip()
    
    if not os.path.exists(list_file):
        print(f"❌ File '{list_file}' tidak ditemukan.")
        exit(1)
    
    batch = []
    count = 0
    processed_count = 0

    # Resume: hitung berapa baris sudah diproses (optional)
    if os.path.exists(found_file):
        with open(found_file, "r") as f:
            processed_count = len(f.readlines())
        if processed_count > 0:
            print(f"Resuming... Sudah {processed_count} URL ditemukan sebelumnya.")
    
    with open(list_file, "r") as f:
        for idx, line in enumerate(f):
            if idx < processed_count:
                continue  # skip yang sudah diproses
            url = line.strip()
            if url:
                batch.append(url)
            if len(batch) >= batch_size:
                count += 1
                print(f"\nProcessing batch #{count}, {len(batch)} URLs")
                process_batch(batch, count)
                batch = []

    # Sisa batch terakhir
    if batch:
        count += 1
        print(f"\nProcessing batch #{count}, {len(batch)} URLs")
        process_batch(batch, count)

    print("\n✅ Semua batch selesai.")