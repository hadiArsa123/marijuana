import socket
import concurrent.futures

def resolve_domain(domain: str):
    domain = domain.strip()
    if not domain:
        return []
    try:
        return socket.gethostbyname_ex(domain)[2]  # ambil semua IP
    except:
        return []

def main():
    # input manual file
    filename = input("Masukkan nama file list domain (contoh: list.txt): ").strip()
    output_file = "result.txt"

    # baca semua domain dari file input
    with open(filename, "r") as f:
        domains = f.readlines()

    results = []
    # gunakan threadpool besar untuk percepatan
    with concurrent.futures.ThreadPoolExecutor(max_workers=1000) as executor:
        futures = [executor.submit(resolve_domain, d) for d in domains]
        for i, future in enumerate(concurrent.futures.as_completed(futures), 1):
            ips = future.result()
            if ips:
                results.extend(ips)

            # tampilkan progress sederhana setiap 10000 domain
            if i % 10000 == 0:
                print(f"Progress: {i}/{len(domains)} domain selesai")

    # simpan hasil ke result.txt
    with open(output_file, "w") as f:
        for ip in results:
            f.write(ip + "\n")

    print(f"[+] Selesai! Total {len(results)} IP disimpan di {output_file}")

if __name__ == "__main__":
    main()